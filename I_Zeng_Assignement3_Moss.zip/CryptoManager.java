public class CryptoManager {
   private static final char LOWER_BOUND = 32;
   private static final char UPPER_BOUND = 95;
   private static final int RANGE = UPPER_BOUND - LOWER_BOUND + 1;

  
   public static boolean stringInBounds(String plainText) {
	    boolean theBounds = true;
	   
	    for (int j = 0; j < plainText.length(); j++) {
	      
	    	if (!((int) plainText.charAt(j) >= LOWER_BOUND &&(int) plainText.charAt(j) <= UPPER_BOUND))
	    	  theBounds = false;
	    }
	    return theBounds; 
   }
	      


  
public static String encryptCaesar(String plainText, int key)
{

	//String variable that encrypted text 
   String encrypt = "";
   
   //A loop that'll encryption
   for (int j=0; j<plainText.length(); j++)
   {
       char char1;
       int charEncrypted;
       
       char1 = plainText.charAt(j); 
       charEncrypted = ((int)char1+key);   
       while(UPPER_BOUND < charEncrypted)
       {
        	   
    	   charEncrypted -= RANGE;
    	   
           }
          
       encrypt += (char)charEncrypted;
   }

   return encrypt;
}



  
public static String encryptBellaso(String plainText, String bellasoStr)
{
	//String variable that'll encrypt bellaso text 
   String encrypt = "";
  
   int bellLength;
  
   bellLength = bellasoStr.length(); 
  
   for (int j = 0; j < plainText.length(); j++)
       {
           char char2;
           int charEncrypted;
           
           char2 = plainText.charAt(j);
           charEncrypted = ((int)char2+(int)bellasoStr.charAt(j%bellLength));
               
           while ((int)UPPER_BOUND < charEncrypted)
               {
        	   
        	   charEncrypted -= RANGE;
        	   
               }
              
           encrypt += (char)charEncrypted;
       }
   
       return encrypt;
}

public static String decryptCaesar(String encryptedText, int key)
{

   String decrypted = "";
   for (int j =0; j < encryptedText.length(); j++)
   {
	   char char3;
	   int intDecrypted;
	   
       char3 = encryptedText.charAt(j);
       intDecrypted = ((int)char3-key);

while (LOWER_BOUND > intDecrypted)
       {
	
	intDecrypted += RANGE;
	
       }

       decrypted += (char)intDecrypted;
   }
   
   return decrypted;
   
}

  
public static String decryptBellaso(String encryptedText, String bellasoStr)
{

	
	String decrypted = "";
   
	int bellLength;
	bellLength = bellasoStr.length();
    
       for (int j = 0; j < encryptedText.length(); j ++)
       {
           char char4;
           int intDecrypted;
           
           char4 = encryptedText.charAt(j);
           intDecrypted = ((int)char4-(int)bellasoStr.charAt(j%bellLength));
         
           while ((int)LOWER_BOUND > intDecrypted)
           {
        	   
        	   intDecrypted += RANGE;
        	   
           }
           
           decrypted += (char)intDecrypted;
           
       }
       
       return decrypted;
       
   }
}