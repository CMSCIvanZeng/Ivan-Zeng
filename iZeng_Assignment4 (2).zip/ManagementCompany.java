import javafx.scene.layout.Region;

public class ManagementCompany {

        
        private final int MAX_PROPERTY = 5;
        private double mgmFeePer;
        private String name;
        private Property[] properties;
        private String taxID;
        private int MGMT_WIDTH = 10;
        private int MGMT_DEPTH = 10;
        private Plot plot ;
        private int index = 0;
        
        public ManagementCompany() {
                
        	properties = new Property[MAX_PROPERTY];
              
        	this.plot = new Plot (0,0,MGMT_WIDTH,MGMT_DEPTH );
        
        	this.name= "";     
        	this.taxID = "";
                
                
        }
        
        
        public ManagementCompany(java.lang.String name, java.lang.String taxID, double mgmFeePer) {
               
        	properties = new Property[MAX_PROPERTY];
               
        	this.plot = new Plot (0,0,MGMT_WIDTH,MGMT_DEPTH );
        	
        	this.mgmFeePer = mgmFeePer;
        	this.name = name;     
        	this.taxID = taxID;
                
   
        	
        }
        
        public ManagementCompany(java.lang.String name, java.lang.String taxID, double mgmFeePer,int x, int y, int width, int depth) {
           
        	properties = new Property[MAX_PROPERTY];
            
        	this.plot = new Plot( x, y, width, depth);  
        	
        	this.mgmFeePer = mgmFeePer;
        	this.name = name; 
        	this.taxID = taxID;
            
        	
            
    }
        public ManagementCompany(ManagementCompany otherCompany) {
               
        	properties = new Property[MAX_PROPERTY];
                
        	name = otherCompany.name;    
        	taxID = otherCompany.taxID;    
        	mgmFeePer = otherCompany.mgmFeePer;
        	plot = otherCompany.plot;
        }
       
        
        
        
        public int getMAX_PROPERTY() {
        	
            return MAX_PROPERTY;
            
    }  
       
        public int addProperty(Property property) {
        	for(int j =0; j < index; j++)
        	{
                if(properties[j].getPlot().overlaps(property.getPlot())) {
                	
                    return -4;
                }
        	}
        	
        	if(index >= MAX_PROPERTY){

        		return -1;

        		}
        	if(property == null) {
        		return -2;
        	}
        	if(!(this.plot.encompasses(property.getPlot()))) {
        		return -3;
        	}
        	
            else{

            	properties[index]=property;
        		index++;
        		
        		
        		return index-1;

        		}   
        }

        
        public int addProperty(String name, String city, double rent, String owner){
                
               
                Property property = new Property(name,city,rent,owner);
                
               for (int j = 0; j<MAX_PROPERTY; j++) {
                	if(properties[j] == null) {
                		property = properties[j];
                	}
                	if (j >= MAX_PROPERTY) {
                		return -1;
                	}
                	if (property == null) {
                		return -2;
                	}
                	if(!(this.plot.encompasses(property.getPlot()))) {
                		return -3;
                	}
                	if(property.getPlot().overlaps(property.getPlot())) {
                		return -4;
                	}
                	
                	   	name = property.getPropertyName();
                	   	city = property.getCity();
                	   	rent = property.getRentAmount();
                	   	owner = property.getOwner();
                }
                
                return MAX_PROPERTY-1;
                
        }
        
   
        
        public int addProperty(String name, String city,double rent, String owner, int x, int y, int width,int depth) {
                
                //a property object that calls the constructor of Plot. 
               
                Property property = new Property(name, city, rent, owner, x, y,width, depth);
               
                //Adds the property object to the properties array.
               
                properties[index] = property;
                
                for (int j = 0; j<MAX_PROPERTY; j++) {
                	if(properties[j] == null) {
                		property = properties[j];
                	}
                	if (j >= MAX_PROPERTY) {
                		return -1;
                	}
                	if (property == null) {
                		return -2;
                	}
                	if(!(this.plot.encompasses(property.getPlot()))) {
                		return -3;
                	}
                	if(property.getPlot().overlaps(property.getPlot())) {
                		return -4;
                	}
        
                }
                
                return MAX_PROPERTY;
                
        }
      
        public double totalRent() {
            double totalRent =0.0 ;
            
            for(int j = 0; j < index; j++) {
                    if(properties[j] == null) {
                            
                    return totalRent;
                            
                    } else {
                    	totalRent += properties[j].getRentAmount();
                    }
            }
            return totalRent;
    }
        
        
        public double maxRentProp() {
            
        	double maxRentAmount = 0.0;
            
            maxRentAmount = properties[maxPropertyRentIndex()].getRentAmount();
            
            
            
            return maxRentAmount;
    }
        
        
        public int maxPropertyRentIndex() {
            int MaxRent=0;
         
            
            for (int j =0; j < index; j++) {
                    
              if(properties[j].getRentAmount() > properties[MaxRent].getRentAmount())
              {
              MaxRent = j;
                          
              }
                    
            }
            
            return MaxRent;
    }
     
        
        
        public String displayPropertyAtIndex(int j) {
            String indexProperty = "";
            
            
            if(properties[j] == null) {
              return indexProperty;
            }
            else {
            	 indexProperty= ("Owner: " + properties[j].getOwner() + "City: " + properties[j].getCity()  + "Property Name: " +
            	            properties[j].getPropertyName() + "Rent Amount: " + properties[j].getRentAmount()+ "Plot: " + properties[j].getPlot());
         
            }
            return indexProperty;
            
    }
      
        public String toString() {
                
                String printAll = "";
                String printOut = "";  
                String printTotalMgm = "";
                double mgnFee;
                mgnFee = mgmFeePer/100;
              
                printOut = ("__________________________________________________"); 
                printTotalMgm = ("Total management Fee: " + totalRent()  * mgnFee); 
                
                
                System.out.println("List of the properties for Alliance, taxID: " + taxID );
                System.out.println(printOut);
                
                
                for(int j = 0; j < index; j++) {
                    
                    	 printAll = (" Property Name: " + properties[j].getPropertyName() +"\n" +
                                 "  Located in: " + properties[j].getCity() + "\n" + 
                                 "  Belonging to: " + properties[j].getOwner() + "\n" + 
                                 "  Rent Amount: " + properties[j].getRentAmount()); 
                 	                           
                    	 	System.out.println(printAll);    
                    	
                }
               
                
                System.out.println(printOut);
                System.out.println(printTotalMgm);
                
            
               String printAlls = "";
               return printAlls;
        }


		public String getName() {
			
			return name;
		}


		public Plot getPlot() {
			
			return plot;
		}

      
                
                
}