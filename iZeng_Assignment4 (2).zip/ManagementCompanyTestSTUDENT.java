import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

class ManagementCompanyTestSTUDENT {
    Property loc1 ,loc2,loc3,loc4,loc5,loc6;
    ManagementCompany location ; 

    @BeforeEach
    public void setUp() throws Exception {
    	loc1 = new Property ("Legacy", "Silver Spring", 5455.00, "Joey Soe",2,1,2,2);
    	loc2 = new Property ("Gentle", "Clarksburg", 4820, " Jay Li",4,1,2,2);
    	loc3 = new Property ("Genshin Lodge", "Germantown", 4200, "James Davidson",6,1,2,2);

       location= new ManagementCompany("Ivan", "44444444",6);

       location.addProperty(loc1);
       location.addProperty(loc2);
       location.addProperty(loc3);
    }

    @AfterEach
    public void tearDown() throws Exception {
    	loc1=loc2=loc3=loc4=loc5=loc6=null;
    	
        location=null;
    }

    @Test
   public void testAddPropertyDefaultPlot() {
    	loc4 = new Property ("Tear", "Yorker", 2613, "Ben Dover",2,5,2,2);
    	loc5 = new Property ("HomeTowner", "Montgomery", 5327, "Jason Campbell",4,5,2,2);
    	loc6 = new Property ("Regular", "Boyds", 1000, "Mateo Ramaiza",6,5,2,2);
    }

    @Test
    public void testMaxRentProp() {
        assertEquals(location.maxRentProp(),5455.0,0);
    }
    @Test
    public void testTotalRent() {
        assertEquals(location.totalRent(),14475.0,0);
    }
}